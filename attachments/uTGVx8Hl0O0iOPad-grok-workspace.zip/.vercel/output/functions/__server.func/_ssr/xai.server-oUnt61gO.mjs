//#region node_modules/.nitro/vite/services/ssr/assets/xai.server-oUnt61gO.js
var CHAT_URL = "https://api.x.ai/v1/chat/completions";
var IMAGE_URL = "https://api.x.ai/v1/images/generations";
var EDIT_URL = "https://api.x.ai/v1/images/edits";
var VIDEO_URL = "https://api.x.ai/v1/videos/generations";
function key() {
	return process.env.XAI_API_KEY?.trim() || null;
}
function aiAvailable() {
	return Boolean(key());
}
async function xfetch(url, body, timeoutMs = 9e4) {
	const k = key();
	if (!k) throw new Error("AI 功能在此环境暂不可用");
	const ctrl = new AbortController();
	const t = setTimeout(() => ctrl.abort(), timeoutMs);
	try {
		return await fetch(url, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${k}`
			},
			body: JSON.stringify(body),
			signal: ctrl.signal
		});
	} finally {
		clearTimeout(t);
	}
}
async function chatJson(args) {
	if (!key()) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	const res = await xfetch(CHAT_URL, {
		model: "grok-4.5",
		temperature: .2,
		max_tokens: args.maxTokens ?? 1800,
		response_format: { type: "json_object" },
		messages: [{
			role: "system",
			content: args.system
		}, {
			role: "user",
			content: args.user
		}]
	});
	if (!res.ok) {
		const err = await res.text().catch(() => "");
		return {
			ok: false,
			error: `模型错误 ${res.status}${err ? `: ${err.slice(0, 180)}` : ""}`
		};
	}
	const text = (await res.json()).choices?.[0]?.message?.content ?? "";
	if (!text) return {
		ok: false,
		error: "模型没有返回内容"
	};
	return {
		ok: true,
		text
	};
}
async function chatText(args) {
	if (!key()) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	const res = await xfetch(CHAT_URL, {
		model: "grok-4.5",
		temperature: .25,
		max_tokens: args.maxTokens ?? 900,
		messages: [{
			role: "system",
			content: args.system
		}, ...args.messages]
	});
	if (!res.ok) {
		const err = await res.text().catch(() => "");
		return {
			ok: false,
			error: `模型错误 ${res.status}${err ? `: ${err.slice(0, 180)}` : ""}`
		};
	}
	return {
		ok: true,
		text: (await res.json()).choices?.[0]?.message?.content ?? ""
	};
}
function pickImage(json) {
	const j = json;
	const first = j.data?.[0];
	return {
		b64: first?.b64_json ?? j.b64_json,
		url: first?.url ?? j.url
	};
}
async function urlToB64(url) {
	const res = await fetch(url);
	if (!res.ok) return null;
	const mime = res.headers.get("content-type")?.split(";")[0] || "image/jpeg";
	return {
		b64: Buffer.from(await res.arrayBuffer()).toString("base64"),
		mime
	};
}
async function normalizeImage(json) {
	const { b64, url } = pickImage(json);
	if (b64) return {
		ok: true,
		b64,
		mime: "image/jpeg"
	};
	if (url) {
		const got = await urlToB64(url);
		if (got) return {
			ok: true,
			b64: got.b64,
			mime: got.mime
		};
	}
	return {
		ok: false,
		error: "生图没有返回可用图像"
	};
}
async function generateImage(args) {
	if (!key()) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	const res = await xfetch(IMAGE_URL, {
		model: "grok-imagine-image-2.0",
		prompt: args.prompt,
		n: 1,
		aspect_ratio: args.aspectRatio ?? "3:4",
		resolution: "1k",
		response_format: "b64_json"
	}, 12e4);
	if (!res.ok) {
		const err = await res.text().catch(() => "");
		return {
			ok: false,
			error: `生图失败 ${res.status}${err ? `: ${err.slice(0, 200)}` : ""}`
		};
	}
	return normalizeImage(await res.json());
}
async function editImage(args) {
	if (!key()) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	const refs = args.images.slice(0, 5).map((src) => ({
		url: src.startsWith("data:") ? src : `data:image/jpeg;base64,${src}`,
		type: "image_url"
	}));
	const body = {
		model: "grok-imagine-image-2.0",
		prompt: args.prompt,
		aspect_ratio: args.aspectRatio ?? "3:4",
		resolution: "1k",
		response_format: "b64_json"
	};
	if (refs.length === 1) body.image = refs[0];
	else body.images = refs;
	const res = await xfetch(EDIT_URL, body, 12e4);
	if (!res.ok) {
		const err = await res.text().catch(() => "");
		return {
			ok: false,
			error: `改图失败 ${res.status}${err ? `: ${err.slice(0, 200)}` : ""}`
		};
	}
	return normalizeImage(await res.json());
}
async function startVideo(args) {
	if (!key()) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	const res = await xfetch(VIDEO_URL, {
		model: "grok-imagine-video-1.5",
		prompt: args.prompt,
		image: { url: args.imageDataUrl },
		duration: 6
	}, 6e4);
	if (!res.ok) {
		const err = await res.text().catch(() => "");
		return {
			ok: false,
			error: `视频失败 ${res.status}${err ? `: ${err.slice(0, 200)}` : ""}`
		};
	}
	const json = await res.json();
	const requestId = json.request_id ?? json.id;
	if (!requestId) return {
		ok: false,
		error: "视频任务没有返回编号"
	};
	return {
		ok: true,
		requestId
	};
}
async function pollVideo(requestId) {
	const k = key();
	if (!k) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	if (!/^[a-zA-Z0-9_-]+$/.test(requestId)) return {
		ok: false,
		error: "编号不合法"
	};
	const res = await fetch(`https://api.x.ai/v1/videos/${requestId}`, { headers: { Authorization: `Bearer ${k}` } });
	if (!res.ok) return {
		ok: false,
		error: `查询失败 ${res.status}`
	};
	const json = await res.json();
	const status = json.status ?? "processing";
	if (status === "done") {
		const url = json.video?.url ?? json.url;
		if (!url) return {
			ok: false,
			error: "视频完成但没有地址"
		};
		return {
			ok: true,
			status: "done",
			url
		};
	}
	if (status === "failed" || status === "expired") return {
		ok: false,
		error: `视频${status}`
	};
	return {
		ok: true,
		status: "processing"
	};
}
function dataUrlFrom(b64, mime = "image/jpeg") {
	if (b64.startsWith("data:")) return b64;
	return `data:${mime};base64,${b64}`;
}
//#endregion
export { aiAvailable, chatJson, chatText, dataUrlFrom, editImage, generateImage, pollVideo, startVideo };
