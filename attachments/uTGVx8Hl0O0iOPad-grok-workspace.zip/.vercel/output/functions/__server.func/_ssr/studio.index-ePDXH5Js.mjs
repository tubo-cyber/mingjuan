import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as BOOKS } from "./catalog-9WcwI-7a.mjs";
import { u as usePrefs } from "./router-GwWX3rwL.mjs";
import { t as AppShell } from "./app-shell-G8noLNFN.mjs";
import { o as useCast } from "./cast-store-eUKdfLQk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio.index-ePDXH5Js.js
var import_jsx_runtime = require_jsx_runtime();
function StudioHome() {
	const script = usePrefs((s) => s.script);
	const people = useCast((s) => s.people);
	const counts = Object.fromEntries(BOOKS.map((b) => [b.id, people.filter((p) => p.bookId === b.id && p.confirmed).length]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-1 font-display text-2xl font-semibold",
			children: "绘像"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-6 text-sm text-muted",
			children: "先锁定人物肖像，读经时本篇插图会沿用同一张脸。"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
			children: BOOKS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/studio/$bookId",
				params: { bookId: b.id },
				className: "min-h-16 rounded-[length:var(--radius-lg)] border border-border bg-surface px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: script === "S" ? b.nameS : b.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-[11px] text-faint",
					children: counts[b.id] ? `已锁定 ${counts[b.id]} 人` : "尚未绘像"
				})]
			}, b.id))
		})
	] });
}
//#endregion
export { StudioHome as component };
