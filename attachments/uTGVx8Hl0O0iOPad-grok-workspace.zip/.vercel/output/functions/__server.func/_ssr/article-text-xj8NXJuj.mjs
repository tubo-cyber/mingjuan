import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent, s as DialogTrigger, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { s as Send, t as X, u as MessageCircle } from "../_libs/lucide-react.mjs";
import { n as cn } from "./app-shell-G8noLNFN.mjs";
import { t as askStudyFn } from "./ai-fns-CcdJ2-pE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/article-text-xj8NXJuj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AskDrawer({ title, source, trigger }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [msgs, setMsgs] = (0, import_react.useState)([]);
	const [err, setErr] = (0, import_react.useState)("");
	async function send() {
		const question = q.trim();
		if (!question || busy) return;
		setQ("");
		setErr("");
		const next = [...msgs, {
			role: "user",
			content: question
		}];
		setMsgs(next);
		setBusy(true);
		const res = await askStudyFn({ data: {
			question,
			title,
			source,
			history: next.slice(-8)
		} });
		setBusy(false);
		if (!res.ok) {
			setErr(res.error);
			return;
		}
		setMsgs([...next, {
			role: "assistant",
			content: res.text
		}]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: trigger ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "grid size-11 place-items-center rounded-[length:var(--radius-md)] text-muted hover:bg-surface hover:text-fg",
				"aria-label": "提问",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-5" })
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-fg/30" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed inset-x-0 bottom-0 z-50 flex max-h-[88dvh] flex-col rounded-t-[length:var(--radius-xl)] border border-border bg-surface shadow-[var(--shadow-soft)] outline-none sm:inset-auto sm:right-3 sm:top-14 sm:bottom-3 sm:w-[26rem] sm:rounded-[length:var(--radius-xl)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-sm font-semibold",
						children: "按本页提问"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						className: "grid size-10 place-items-center rounded-[length:var(--radius-md)] hover:bg-raised",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-4 pt-2 text-xs text-faint",
					children: "答案依据本页注解与经文。不确定处会标明。"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1 space-y-3 overflow-y-auto px-4 py-3",
					children: [
						msgs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "例如：这一章的「空虚混沌」在注解里怎么讲？"
						}) : null,
						msgs.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: m.role === "user" ? "ml-8 rounded-[length:var(--radius-md)] bg-fg px-3 py-2 text-sm text-bg" : "mr-4 rounded-[length:var(--radius-md)] bg-raised px-3 py-2 text-sm leading-relaxed whitespace-pre-wrap",
							children: m.content
						}, i)),
						busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-faint",
							children: "正在对照本页注解…"
						}) : null,
						err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-accent",
							children: err
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex gap-2 border-t border-border p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]",
					onSubmit: (e) => {
						e.preventDefault();
						send();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "问这一页…",
						className: "h-11 min-w-0 flex-1 rounded-[length:var(--radius-md)] border border-border bg-raised px-3 text-sm outline-none"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: busy,
						className: "grid size-11 place-items-center rounded-[length:var(--radius-md)] bg-fg text-bg disabled:opacity-40",
						"aria-label": "送出",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
					})]
				})
			]
		})] })]
	});
}
function escapeRe(s) {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function highlight(text, marks) {
	const names = marks.flatMap((m) => [m.name, ...m.aliases]).filter((n) => n.length >= 2).sort((a, b) => b.length - a.length);
	if (!names.length) return text;
	const re = new RegExp(`(${names.map(escapeRe).join("|")})`, "g");
	return text.split(re).map((part, i) => {
		if (!marks.find((m) => m.name === part || m.aliases.includes(part))) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: part }, i);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("mark", {
			className: "rounded-sm bg-transparent font-medium text-seal underline decoration-border underline-offset-4",
			children: part
		}, i);
	});
}
function ReaderView({ title, blocks, marks = [] }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "reader-prose mx-auto max-w-[40rem]",
		style: {
			fontFamily: "var(--reader-font)",
			fontSize: "var(--reader-size, 19px)",
			lineHeight: "var(--reader-leading, 1.9)"
		},
		children: [blocks.map((b, i) => {
			if (b.t === "title") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mb-6 text-center font-semibold tracking-wide",
				style: {
					fontSize: "1.35em",
					lineHeight: 1.4
				},
				children: b.text
			}, i);
			if (b.t === "h") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 mb-3 font-semibold text-seal",
				style: { fontSize: "1.08em" },
				children: highlight(b.text, marks)
			}, i);
			if (b.t === "verse") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "my-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "verse-ref",
					children: [
						"【",
						b.ref,
						"】"
					]
				}), b.quote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "verse-quote",
					children: highlight(b.quote, marks)
				}) : null]
			}, i);
			if (b.t === "note") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "my-3 text-[0.95em] text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "note-chip",
					children: b.label
				}), highlight(b.text, marks)]
			}, i);
			if (b.t === "link") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "my-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "underline decoration-border underline-offset-4",
					href: b.href,
					children: b.text
				})
			}, i);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("my-3"),
				children: highlight(b.text, marks)
			}, i);
		}), blocks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: title
		}) : null]
	});
}
function blocksToText(blocks) {
	return blocks.map((b) => {
		if (b.t === "verse") return `【${b.ref}】${b.quote ?? ""}`;
		if (b.t === "note") return `〔${b.label}〕${b.text}`;
		if (b.t === "link") return b.text;
		return b.text;
	}).filter(Boolean).join("\n");
}
//#endregion
export { ReaderView as n, blocksToText as r, AskDrawer as t };
