import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cast-store-eUKdfLQk.js
var DB = "mingjuan-v1";
var STORE = "img";
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB, 1);
		req.onupgradeneeded = () => {
			if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
}
async function saveImage(key, dataUrl) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(dataUrl, key);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
async function loadImage(key) {
	const db = await openDb();
	return new Promise((resolve, reject) => {
		const q = db.transaction(STORE, "readonly").objectStore(STORE).get(key);
		q.onsuccess = () => resolve(q.result ?? null);
		q.onerror = () => reject(q.error);
	});
}
async function deleteImage(key) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).delete(key);
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
}
var useCast = create()(persist((set, get) => ({
	people: [],
	styleByBook: {},
	upsertPeople: (bookId, incoming) => set((s) => {
		const style = s.styleByBook[bookId] ?? "oil";
		const next = [...s.people.filter((p) => p.bookId !== bookId || p.confirmed)];
		for (const row of incoming) {
			const exists = next.find((p) => p.bookId === bookId && p.id === row.id);
			if (exists) Object.assign(exists, {
				name: row.name,
				aliases: row.aliases,
				role: row.role,
				chapters: row.chapters,
				importance: row.importance,
				bibleLook: row.bibleLook,
				portraitBrief: row.portraitBrief
			});
			else next.push({
				...row,
				bookId,
				styleId: style,
				confirmed: false
			});
		}
		return { people: next };
	}),
	setStyle: (bookId, style) => set((s) => ({
		styleByBook: {
			...s.styleByBook,
			[bookId]: style
		},
		people: s.people.map((p) => p.bookId === bookId && !p.confirmed ? {
			...p,
			styleId: style
		} : p)
	})),
	confirm: (bookId, id) => set((s) => ({ people: s.people.map((p) => p.bookId === bookId && p.id === id ? {
		...p,
		confirmed: true
	} : p) })),
	forget: (bookId, id) => set((s) => ({ people: s.people.filter((p) => !(p.bookId === bookId && p.id === id)) })),
	peopleOf: (bookId) => get().people.filter((p) => p.bookId === bookId)
}), { name: "mingjuan-cast" }));
function imgKey(bookId, id) {
	return `${bookId}:${id}`;
}
function mentioned(people, text) {
	return people.filter((p) => {
		return [p.name, ...p.aliases].filter((n) => n.length >= 2).some((n) => text.includes(n));
	});
}
//#endregion
export { saveImage as a, mentioned as i, imgKey as n, useCast as o, loadImage as r, deleteImage as t };
