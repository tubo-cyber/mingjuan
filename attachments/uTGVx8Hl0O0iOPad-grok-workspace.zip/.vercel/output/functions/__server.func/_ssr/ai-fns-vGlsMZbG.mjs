import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { c as articlePath, n as BOOK_BY_ID } from "./catalog-9WcwI-7a.mjs";
import { n as MODESTY, r as stylePrompt } from "./art-styles-1KQQQM2v.mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-fns-vGlsMZbG.js
function clip(s, n) {
	return s.length <= n ? s : s.slice(0, n) + "…";
}
function blocksToText(blocks) {
	return blocks.map((b) => {
		if (b.t === "verse") return `【${b.ref}】${b.quote ?? ""}`;
		if (b.t === "note") return `〔${b.label}〕${b.text ?? ""}`;
		return b.text ?? "";
	}).filter(Boolean).join("\n");
}
var extractPeopleFn_createServerFn_handler = createServerRpc({
	id: "5b7ce5c602e640d1231901ed5f9b8b5cf61717457649875fa73d8d743282f9e8",
	name: "extractPeopleFn",
	filename: "src/lib/ai-fns.ts"
}, (opts) => extractPeopleFn.__executeServer(opts));
var extractPeopleFn = createServerFn({ method: "POST" }).validator(object({
	bookId: string(),
	from: number().int().min(1).max(150),
	to: number().int().min(1).max(150)
})).handler(extractPeopleFn_createServerFn_handler, async ({ data }) => {
	const { chatJson, aiAvailable } = await import("./xai.server-oUnt61gO.mjs");
	if (!aiAvailable()) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	const book = BOOK_BY_ID[data.bookId];
	if (!book) return {
		ok: false,
		error: "查无此书卷"
	};
	const from = Math.min(data.from, data.to);
	const to = Math.max(data.from, data.to);
	const { fetchArticle } = await import("./fetch-source.server-DbzFpyb8.mjs");
	const intro = await fetchArticle(articlePath(book, "C", 0, "T"), `${book.name}導論`);
	const source = clip(`# ${intro.title}\n${blocksToText(intro.blocks)}`, 9e3);
	const result = await chatJson({
		maxTokens: 1600,
		system: "你是谨慎的圣经教师。只根据用户提供的经文注解摘录，并对照该卷该段圣经记载，列出真正推动叙事的重心人物。不要列族谱里一长串仅出现一次的名字。不要发明经文没有的外貌细节；外貌只能写经文或注解明确说过的，否则写“经文未细写外貌，请按古代近东常民、端庄服饰来画”。用 JSON。",
		user: `书卷：${book.name}（${book.abbr}）第 ${from} 至 ${to} 章。\n\n注解摘录：\n${source}\n\n请输出 JSON：{"people":[{"id":"slug-en","name":"繁体中文惯用名","aliases":["别名"],"role":"一句身份","chapters":[出现章号],"importance":"为何是重心而非族谱路人","bibleLook":"经文/注解对外貌或气质的记载，没有就如实说明","portraitBrief":"给画家的端庄人物设定，成人，历史可信"}]}。people 最多 8 个。id 用英文短横线，稳定可复用（如 abraham, sarah, joseph）。`
	});
	if (!result.ok) return result;
	try {
		const parsed = JSON.parse(result.text);
		const skip = /^(神|上帝|耶和華|耶和华|父神|主神|真神)$/;
		return {
			ok: true,
			people: (parsed.people ?? []).filter((p) => !skip.test((p.name ?? "").trim())).slice(0, 8).map((p) => ({
				id: String(p.id || p.name).toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-"),
				name: p.name,
				aliases: (p.aliases ?? []).slice(0, 6),
				role: p.role ?? "",
				chapters: (p.chapters ?? []).filter((n) => n >= from && n <= to).slice(0, 12),
				importance: p.importance ?? "",
				bibleLook: p.bibleLook ?? "",
				portraitBrief: p.portraitBrief ?? ""
			})),
			bookName: book.name,
			from,
			to
		};
	} catch {
		return {
			ok: false,
			error: "人物名单解析失败，请再试一次"
		};
	}
});
var makePortraitFn_createServerFn_handler = createServerRpc({
	id: "f9b9c9b95c254d332b931ecca7a7704b9d8a2bddafe1e1966483cf9b2976558b",
	name: "makePortraitFn",
	filename: "src/lib/ai-fns.ts"
}, (opts) => makePortraitFn.__executeServer(opts));
var makePortraitFn = createServerFn({ method: "POST" }).validator(object({
	name: string().min(1).max(40),
	brief: string().max(800),
	look: string().max(600),
	styleId: string(),
	lockedImage: string().max(18e5).optional()
})).handler(makePortraitFn_createServerFn_handler, async ({ data }) => {
	const { generateImage, editImage, dataUrlFrom, aiAvailable } = await import("./xai.server-oUnt61gO.mjs");
	if (!aiAvailable()) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	const style = stylePrompt(data.styleId);
	const prompt = `${MODESTY}
Single portrait of the biblical figure ${data.name}.
Biblical notes on appearance: ${data.look}
Character brief: ${data.brief}
Art direction: ${style}
Half-length or three-quarter portrait, facing the viewer slightly, calm expression, readable face, plain ancient backdrop, no text, no watermark, no collage.`;
	const out = data.lockedImage ? await editImage({
		prompt: `${prompt}\nKeep the SAME face, age, hair, skin, and identity as the reference portrait. Only refresh pose/lighting within the chosen style.`,
		images: [data.lockedImage],
		aspectRatio: "3:4"
	}) : await generateImage({
		prompt,
		aspectRatio: "3:4"
	});
	if (!out.ok) return out;
	return {
		ok: true,
		dataUrl: dataUrlFrom(out.b64, out.mime)
	};
});
var makeSceneFn_createServerFn_handler = createServerRpc({
	id: "10cea72e0ea4c5a97438e9aa2a6b69104214469d65162744eddce01f9a072be5",
	name: "makeSceneFn",
	filename: "src/lib/ai-fns.ts"
}, (opts) => makeSceneFn.__executeServer(opts));
var makeSceneFn = createServerFn({ method: "POST" }).validator(object({
	bookName: string(),
	chapter: number().int(),
	passage: string().max(4e3),
	styleId: string(),
	people: array(object({
		name: string(),
		image: string().max(18e5)
	})).max(4)
})).handler(makeSceneFn_createServerFn_handler, async ({ data }) => {
	const { generateImage, editImage, dataUrlFrom, aiAvailable } = await import("./xai.server-oUnt61gO.mjs");
	if (!aiAvailable()) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	const style = stylePrompt(data.styleId);
	const names = data.people.map((p) => p.name).join("、") || "场景中的人物";
	const prompt = `${MODESTY}
Narrative illustration of ${data.bookName} chapter ${data.chapter}.
Figures who MUST keep identity from the reference portraits: ${names}.
Passage cues: ${clip(data.passage, 1200)}
Art direction: ${style}
Wide story scene, historically plausible setting, modest clothing, no text, no speech bubbles, no modern objects. If references are provided, every named person must match those faces exactly.`;
	const out = data.people.length > 0 ? await editImage({
		prompt,
		images: data.people.map((p) => p.image),
		aspectRatio: "16:9"
	}) : await generateImage({
		prompt,
		aspectRatio: "16:9"
	});
	if (!out.ok) return out;
	return {
		ok: true,
		dataUrl: dataUrlFrom(out.b64, out.mime)
	};
});
var askStudyFn_createServerFn_handler = createServerRpc({
	id: "4e9d8d773ce1c75eee77a24bf65a6da0de5c2d8f72310f05602b7f87df0c2b91",
	name: "askStudyFn",
	filename: "src/lib/ai-fns.ts"
}, (opts) => askStudyFn.__executeServer(opts));
var askStudyFn = createServerFn({ method: "POST" }).validator(object({
	question: string().min(1).max(600),
	title: string().max(120),
	source: string().max(12e3),
	history: array(object({
		role: _enum(["user", "assistant"]),
		content: string().max(2e3)
	})).max(8).optional()
})).handler(askStudyFn_createServerFn_handler, async ({ data }) => {
	const { chatText, aiAvailable } = await import("./xai.server-oUnt61gO.mjs");
	if (!aiAvailable()) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	return chatText({
		system: `你是明卷查经的助读。必须：
1. 优先依据用户提供的「本页注解与经文摘录」作答。
2. 若摘录不足，只能补充圣经里清楚的平行经文，并标明出处。
3. 不确定或注解有争议时，要明说，不要武断。
4. 不可编造原文、不可编造注释者没写过的话。
5. 用繁体中文，条理清楚，适当引用【章节】。
6. 不谈与经文无关的内容，不作灵媒式预言。
当前篇名：${data.title}`,
		messages: [...(data.history ?? []).map((h) => ({
			role: h.role,
			content: h.content
		})), {
			role: "user",
			content: `【本页摘录】\n${clip(data.source, 1e4)}\n\n【问题】\n${data.question}`
		}],
		maxTokens: 900
	});
});
var startClipFn_createServerFn_handler = createServerRpc({
	id: "1fa244060d9e326902e4927fb7076b3a6812f5f24461d510fdb058b2f2192ea6",
	name: "startClipFn",
	filename: "src/lib/ai-fns.ts"
}, (opts) => startClipFn.__executeServer(opts));
var startClipFn = createServerFn({ method: "POST" }).validator(object({
	image: string().max(18e5),
	name: string().max(40)
})).handler(startClipFn_createServerFn_handler, async ({ data }) => {
	const { startVideo, aiAvailable } = await import("./xai.server-oUnt61gO.mjs");
	if (!aiAvailable()) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	return startVideo({
		imageDataUrl: data.image,
		prompt: `Gentle cinematic motion of this still biblical portrait of ${data.name}: slow camera push-in, fabric and hair move slightly in desert wind, reverent lighting, no extra characters, no text.`
	});
});
var pollClipFn_createServerFn_handler = createServerRpc({
	id: "cc322a8052a92a6c92aea8a3aa3cc3faec780468a30c7c2981ac6521dcedee53",
	name: "pollClipFn",
	filename: "src/lib/ai-fns.ts"
}, (opts) => pollClipFn.__executeServer(opts));
var pollClipFn = createServerFn({ method: "POST" }).validator(object({ requestId: string().min(4).max(80) })).handler(pollClipFn_createServerFn_handler, async ({ data }) => {
	const { pollVideo, aiAvailable } = await import("./xai.server-oUnt61gO.mjs");
	if (!aiAvailable()) return {
		ok: false,
		error: "AI 功能在此环境暂不可用"
	};
	return pollVideo(data.requestId);
});
//#endregion
export { askStudyFn_createServerFn_handler, extractPeopleFn_createServerFn_handler, makePortraitFn_createServerFn_handler, makeSceneFn_createServerFn_handler, pollClipFn_createServerFn_handler, startClipFn_createServerFn_handler };
