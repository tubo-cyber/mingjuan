//#region node_modules/.nitro/vite/services/ssr/assets/compress-image-CjiPUKmi.js
function compressDataUrl(src, max = 720, quality = .82) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => {
			const scale = Math.min(1, max / Math.max(img.width, img.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(img.width * scale));
			canvas.height = Math.max(1, Math.round(img.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				resolve(src);
				return;
			}
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			resolve(canvas.toDataURL("image/jpeg", quality));
		};
		img.onerror = () => reject(/* @__PURE__ */ new Error("图像无法读取"));
		img.src = src;
	});
}
//#endregion
export { compressDataUrl as t };
