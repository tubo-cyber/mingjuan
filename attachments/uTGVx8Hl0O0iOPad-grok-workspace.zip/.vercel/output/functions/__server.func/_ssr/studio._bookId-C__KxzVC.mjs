import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as BOOK_BY_ID } from "./catalog-9WcwI-7a.mjs";
import { t as ART_STYLES } from "./art-styles-1KQQQM2v.mjs";
import { a as Sparkles, d as LoaderCircle, g as ChevronLeft, i as Star } from "../_libs/lucide-react.mjs";
import { i as Route$2 } from "./router-GwWX3rwL.mjs";
import { n as cn, t as AppShell } from "./app-shell-G8noLNFN.mjs";
import { a as pollClipFn, n as extractPeopleFn, o as startClipFn, r as makePortraitFn } from "./ai-fns-CcdJ2-pE.mjs";
import { a as saveImage, n as imgKey, o as useCast, r as loadImage, t as deleteImage } from "./cast-store-eUKdfLQk.mjs";
import { t as compressDataUrl } from "./compress-image-CjiPUKmi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio._bookId-C__KxzVC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudioPage() {
	const { bookId } = Route$2.useParams();
	const book = BOOK_BY_ID[bookId];
	const people = useCast((s) => s.people).filter((p) => p.bookId === bookId);
	const upsertPeople = useCast((s) => s.upsertPeople);
	const styleId = useCast((s) => s.styleByBook[bookId] ?? "oil");
	const setStyle = useCast((s) => s.setStyle);
	const [from, setFrom] = (0, import_react.useState)(1);
	const [to, setTo] = (0, import_react.useState)(Math.min(11, book?.chapters ?? 1));
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)("");
	if (!book) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "绘像",
		children: "查无此书卷"
	});
	async function extract() {
		setBusy(true);
		setErr("");
		try {
			const res = await extractPeopleFn({ data: {
				bookId,
				from,
				to
			} });
			if (!res.ok) {
				setErr(res.error);
				return;
			}
			upsertPeople(bookId, res.people);
		} catch (e) {
			setErr(e instanceof Error ? e.message : "提取失败");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: `${book.name}绘像`,
		back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/studio",
			className: "grid size-11 place-items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-muted",
				children: "选定章节，只提取叙事重心人物（族谱路人会略过）。锁定肖像后，后文插图会沿用同一张脸。"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs text-muted",
					children: ["从第", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 1,
						max: book.chapters,
						value: from,
						onChange: (e) => setFrom(Number(e.target.value)),
						className: "mt-1 h-11 w-full rounded-[length:var(--radius-md)] border border-border bg-surface px-3 text-sm text-fg"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-xs text-muted",
					children: ["到第", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 1,
						max: book.chapters,
						value: to,
						onChange: (e) => setTo(Number(e.target.value)),
						className: "mt-1 h-11 w-full rounded-[length:var(--radius-md)] border border-border bg-surface px-3 text-sm text-fg"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-2 text-xs font-medium text-muted",
				children: "画风"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 grid grid-cols-2 gap-2",
				children: ART_STYLES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setStyle(bookId, s.id),
					className: cn("min-h-11 rounded-[length:var(--radius-md)] border px-3 text-sm", styleId === s.id ? "border-fg bg-fg text-bg" : "border-border bg-surface"),
					children: s.label
				}, s.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => void extract(),
				disabled: busy,
				className: "mb-6 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-[length:var(--radius-md)] bg-fg text-sm text-bg disabled:opacity-40",
				children: [
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }),
					"提取第 ",
					Math.min(from, to),
					"–",
					Math.max(from, to),
					" 章重心人物"
				]
			}),
			err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-xs text-accent",
				children: err
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonCard, {
					person: p,
					styleId: p.confirmed ? p.styleId : styleId
				}, p.id))
			})
		]
	});
}
function PersonCard({ person, styleId }) {
	const confirm = useCast((s) => s.confirm);
	const forget = useCast((s) => s.forget);
	const [img, setImg] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [clip, setClip] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)("");
	const key = imgKey(person.bookId, person.id);
	(0, import_react.useEffect)(() => {
		loadImage(key).then(setImg);
	}, [key]);
	async function gen() {
		setBusy(true);
		setErr("");
		const res = await makePortraitFn({ data: {
			name: person.name,
			brief: person.portraitBrief,
			look: person.bibleLook,
			styleId,
			lockedImage: person.confirmed ? img ?? void 0 : void 0
		} });
		setBusy(false);
		if (!res.ok) {
			setErr(res.error);
			return;
		}
		const compact = await compressDataUrl(res.dataUrl);
		setDraft(compact);
	}
	async function lock(src) {
		const compact = await compressDataUrl(src);
		await saveImage(key, compact);
		setImg(compact);
		setDraft(null);
		confirm(person.bookId, person.id);
	}
	async function animate() {
		if (!img) return;
		setBusy(true);
		setErr("");
		const start = await startClipFn({ data: {
			image: img,
			name: person.name
		} });
		if (!start.ok) {
			setBusy(false);
			setErr(start.error);
			return;
		}
		for (let i = 0; i < 24; i++) {
			await new Promise((r) => setTimeout(r, 2500));
			const poll = await pollClipFn({ data: { requestId: start.requestId } });
			if (!poll.ok) {
				setBusy(false);
				setErr(poll.error);
				return;
			}
			if (poll.status === "done") {
				setClip(poll.url);
				setBusy(false);
				return;
			}
		}
		setBusy(false);
		setErr("视频仍在生成，请稍后再试");
	}
	const shown = draft ?? img;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-[length:var(--radius-lg)] border border-border bg-surface p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-28 shrink-0 overflow-hidden rounded-[length:var(--radius-md)] bg-raised",
					children: shown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: shown,
						alt: person.name,
						className: "size-full object-cover"
					}) : null
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "font-medium",
								children: [person.name, person.confirmed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "ml-1 inline size-3.5 fill-accent text-accent" }) : null]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-xs text-faint",
								onClick: () => {
									deleteImage(key);
									forget(person.bookId, person.id);
								},
								children: "移除"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: person.role
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs leading-relaxed text-faint",
							children: person.importance
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs leading-relaxed text-muted",
							children: person.bibleLook
						})
					]
				})]
			}),
			err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-accent",
				children: err
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: busy,
						onClick: () => void gen(),
						className: "inline-flex min-h-10 items-center rounded-[length:var(--radius-md)] border border-border px-3 text-xs disabled:opacity-40",
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-1 size-3.5 animate-spin" }) : null, person.confirmed ? "同脸重绘" : "生成肖像"]
					}),
					draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void lock(draft),
						className: "inline-flex min-h-10 items-center rounded-[length:var(--radius-md)] bg-fg px-3 text-xs text-bg",
						children: "锁定这张脸"
					}) : null,
					person.confirmed && img ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						onClick: () => void animate(),
						className: "inline-flex min-h-10 items-center rounded-[length:var(--radius-md)] border border-border px-3 text-xs disabled:opacity-40",
						children: "做成短片"
					}) : null
				]
			}),
			clip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				src: clip,
				controls: true,
				className: "mt-3 w-full rounded-[length:var(--radius-md)]"
			}) : null
		]
	});
}
//#endregion
export { StudioPage as component };
