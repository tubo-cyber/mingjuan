import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as articlePath, i as KINDS, n as BOOK_BY_ID } from "./catalog-9WcwI-7a.mjs";
import { t as ART_STYLES } from "./art-styles-1KQQQM2v.mjs";
import { d as LoaderCircle, g as ChevronLeft, h as ChevronRight, i as Star, l as Palette, m as Image } from "../_libs/lucide-react.mjs";
import { d as getArticleFn, l as useLibrary, n as Route, u as usePrefs } from "./router-GwWX3rwL.mjs";
import { n as cn, t as AppShell } from "./app-shell-G8noLNFN.mjs";
import { i as makeSceneFn } from "./ai-fns-CcdJ2-pE.mjs";
import { n as ReaderView, r as blocksToText, t as AskDrawer } from "./article-text-xj8NXJuj.mjs";
import { a as saveImage, i as mentioned, n as imgKey, o as useCast, r as loadImage } from "./cast-store-eUKdfLQk.mjs";
import { t as compressDataUrl } from "./compress-image-CjiPUKmi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/read._bookId._kind._chap-DXFKujIE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SceneStrip({ bookId, bookName, chapter, passage }) {
	const people = useCast((s) => s.people).filter((p) => p.bookId === bookId && p.confirmed);
	const styleId = useCast((s) => s.styleByBook[bookId] ?? "oil");
	const hits = (0, import_react.useMemo)(() => mentioned(people, passage), [people, passage]);
	const [portraits, setPortraits] = (0, import_react.useState)({});
	const [scene, setScene] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let alive = true;
		Promise.all(hits.map(async (p) => {
			const img = await loadImage(imgKey(bookId, p.id));
			return [p.id, img];
		})).then((rows) => {
			if (!alive) return;
			const map = {};
			for (const [id, img] of rows) if (img) map[id] = img;
			setPortraits(map);
		});
		return () => {
			alive = false;
		};
	}, [bookId, hits]);
	(0, import_react.useEffect)(() => {
		const key = `scene:${bookId}:${chapter}:${styleId}`;
		loadImage(key).then((img) => setScene(img));
	}, [
		bookId,
		chapter,
		styleId
	]);
	async function draw() {
		setBusy(true);
		setErr("");
		const refs = hits.map((p) => portraits[p.id] ? {
			name: p.name,
			image: portraits[p.id]
		} : null).filter(Boolean);
		const res = await makeSceneFn({ data: {
			bookName,
			chapter,
			passage: passage.slice(0, 3500),
			styleId,
			people: refs
		} });
		setBusy(false);
		if (!res.ok) {
			setErr(res.error);
			return;
		}
		const compact = await compressDataUrl(res.dataUrl, 960, .8);
		setScene(compact);
		await saveImage(`scene:${bookId}:${chapter}:${styleId}`, compact);
	}
	const styleLabel = ART_STYLES.find((s) => s.id === styleId)?.label ?? "油画";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-6 overflow-hidden rounded-[length:var(--radius-lg)] border border-border bg-surface",
		children: [
			scene ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: scene,
				alt: `${bookName}第${chapter}章插图`,
				className: "aspect-video w-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex aspect-video items-center justify-center bg-raised px-6 text-center text-sm text-muted",
				children: "为本篇生成插图。已锁定的人物会沿用同一张脸。"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 px-3 py-2",
				children: [
					hits.slice(0, 6).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1 text-xs text-muted",
						children: [portraits[p.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: portraits[p.id],
							alt: "",
							className: "size-6 rounded-full object-cover"
						}) : null, p.name]
					}, p.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-auto text-[11px] text-faint",
						children: styleLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void draw(),
						disabled: busy,
						className: "inline-flex min-h-10 items-center gap-1 rounded-[length:var(--radius-md)] bg-fg px-3 text-xs text-bg disabled:opacity-40",
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-3.5" }), scene ? "重绘本篇" : "生成插图"]
					})
				]
			}),
			err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-3 pb-2 text-xs text-accent",
				children: err
			}) : null
		]
	});
}
function ReadPage() {
	const { bookId, kind, chap } = Route.useParams();
	const { article } = Route.useLoaderData();
	const book = BOOK_BY_ID[bookId];
	const script = usePrefs((s) => s.script);
	const n = Number(chap);
	const k = kind;
	const max = book.chapters + 1;
	const prev = n > 0 ? n - 1 : null;
	const next = n < max ? n + 1 : null;
	const href = `/read/${bookId}/${kind}/${chap}`;
	const pushHistory = useLibrary((s) => s.pushHistory);
	const toggleStar = useLibrary((s) => s.toggleStar);
	const starred = useLibrary((s) => s.stars.some((x) => x.href === href));
	const [live, setLive] = (0, import_react.useState)(article);
	const people = useCast((s) => s.people).filter((p) => p.bookId === bookId && p.confirmed);
	(0, import_react.useEffect)(() => {
		setLive(article);
	}, [article]);
	(0, import_react.useEffect)(() => {
		if (script === "T") return;
		let alive = true;
		const path = articlePath(book, k, n, script);
		getArticleFn({ data: {
			path,
			title: article.title
		} }).then((a) => {
			if (alive && a.status === 200) setLive(a);
		});
		return () => {
			alive = false;
		};
	}, [
		script,
		book,
		k,
		n,
		article.title
	]);
	(0, import_react.useEffect)(() => {
		pushHistory({
			href,
			title: live.title
		});
	}, [
		href,
		live.title,
		pushHistory
	]);
	const name = script === "S" ? book.nameS : book.name;
	const source = (0, import_react.useMemo)(() => blocksToText(live.blocks), [live.blocks]);
	const marks = people.map((p) => ({
		id: p.id,
		name: p.name,
		aliases: p.aliases
	}));
	if (live.isPdf) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: live.title,
		back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/book/$bookId",
			params: { bookId },
			className: "grid size-11 place-items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindBar, {
				bookId,
				chap,
				current: k
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-muted",
				children: "此項為 PDF 譯文檔，請開啟原文。"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: live.sourceUrl,
				target: "_blank",
				rel: "noreferrer",
				className: "inline-flex min-h-11 items-center rounded-[length:var(--radius-md)] bg-fg px-4 text-sm text-bg",
				children: "開啟 PDF"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: `${name} ${n === 0 ? "導" : n > book.chapters ? "綜" : n}`,
		back: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/book/$bookId",
			params: { bookId },
			className: "grid size-11 place-items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
		}),
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AskDrawer, {
					title: live.title,
					source
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/studio/$bookId",
					params: { bookId },
					className: "grid size-11 place-items-center text-muted",
					"aria-label": "绘像",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center",
					onClick: () => toggleStar({
						href,
						title: live.title
					}),
					"aria-label": "收藏",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cn("size-5", starred ? "fill-accent text-accent" : "text-muted") })
				})
			]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindBar, {
				bookId,
				chap,
				current: k
			}),
			n >= 1 && n <= book.chapters ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SceneStrip, {
				bookId,
				bookName: name,
				chapter: n,
				passage: source
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReaderView, {
				title: live.title,
				blocks: live.blocks,
				marks
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex items-center justify-between gap-3",
				children: [prev !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/read/$bookId/$kind/$chap",
					params: {
						bookId,
						kind,
						chap: String(prev)
					},
					className: "inline-flex min-h-11 items-center gap-1 rounded-[length:var(--radius-md)] border border-border bg-surface px-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), "上一章"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), next !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/read/$bookId/$kind/$chap",
					params: {
						bookId,
						kind,
						chap: String(next)
					},
					className: "inline-flex min-h-11 items-center gap-1 rounded-[length:var(--radius-md)] border border-border bg-surface px-3 text-sm",
					children: ["下一章", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-center text-[11px] text-faint",
				children: "資料來源：華人基督徒查經資料網站 · 僅重排版面"
			})
		]
	});
}
function KindBar({ bookId, chap, current }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-6 -mx-1 flex gap-1 overflow-x-auto pb-1",
		children: KINDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/read/$bookId/$kind/$chap",
			params: {
				bookId,
				kind: item.code,
				chap
			},
			className: cn("shrink-0 rounded-full px-3 py-2 text-xs", current === item.code ? "bg-fg text-bg" : "bg-surface text-muted border border-border"),
			children: item.name
		}, item.code))
	});
}
//#endregion
export { ReadPage as component };
