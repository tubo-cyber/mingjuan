//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-_aJM_SKA.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/columns",
			"/intro",
			"/studio",
			"/topics",
			"/view",
			"/book/$bookId",
			"/column/$slug",
			"/topic/$topicId",
			"/read/$bookId/$kind/$chap"
		],
		preloads: [
			"/assets/index-B7pV8Juo.js",
			"/assets/useStore-CP8wJgJA.js",
			"/assets/prefs-C1cY4iRi.js",
			"/assets/createServerFn-ClWmCfQD.js",
			"/assets/matchContext-DG9VXIaP.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B7pV8Juo.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-vgOoiClr.js",
			"/assets/useNavigate-B0tGo7qX.js",
			"/assets/app-shell-BVgSiuuC.js"
		]
	},
	"/columns": {
		filePath: "/workspace/src/routes/columns.tsx",
		children: void 0,
		preloads: ["/assets/columns-70tZlZor.js", "/assets/app-shell-BVgSiuuC.js"]
	},
	"/intro": {
		filePath: "/workspace/src/routes/intro.tsx",
		children: void 0,
		preloads: ["/assets/intro-OWJTY24W.js", "/assets/app-shell-BVgSiuuC.js"]
	},
	"/studio": {
		filePath: "/workspace/src/routes/studio.tsx",
		children: ["/studio/$bookId", "/studio/"],
		preloads: ["/assets/studio-Dq1y6U_E.js"]
	},
	"/topics": {
		filePath: "/workspace/src/routes/topics.tsx",
		children: void 0,
		preloads: ["/assets/topics-DKyNKT7B.js", "/assets/app-shell-BVgSiuuC.js"]
	},
	"/view": {
		filePath: "/workspace/src/routes/view.tsx",
		children: void 0,
		preloads: [
			"/assets/view-B_libHBb.js",
			"/assets/app-shell-BVgSiuuC.js",
			"/assets/chevron-left-CMn1hByi.js",
			"/assets/article-text-DjT7UOpo.js",
			"/assets/ai-fns-BEg1-CQe.js"
		]
	},
	"/book/$bookId": {
		filePath: "/workspace/src/routes/book.$bookId.tsx",
		children: void 0,
		preloads: [
			"/assets/book._bookId-gkEeHPUT.js",
			"/assets/app-shell-BVgSiuuC.js",
			"/assets/chevron-left-CMn1hByi.js"
		]
	},
	"/column/$slug": {
		filePath: "/workspace/src/routes/column.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/column._slug-CC-32ITO.js",
			"/assets/app-shell-BVgSiuuC.js",
			"/assets/chevron-left-CMn1hByi.js"
		]
	},
	"/studio/$bookId": {
		filePath: "/workspace/src/routes/studio.$bookId.tsx",
		children: void 0,
		preloads: [
			"/assets/studio._bookId-B9zhF9c0.js",
			"/assets/app-shell-BVgSiuuC.js",
			"/assets/chevron-left-CMn1hByi.js",
			"/assets/compress-image-DnPnMof_.js",
			"/assets/ai-fns-BEg1-CQe.js",
			"/assets/cast-store-C1KXldYv.js"
		]
	},
	"/topic/$topicId": {
		filePath: "/workspace/src/routes/topic.$topicId.tsx",
		children: void 0,
		preloads: [
			"/assets/topic._topicId-DQiX86Dj.js",
			"/assets/app-shell-BVgSiuuC.js",
			"/assets/chevron-left-CMn1hByi.js"
		]
	},
	"/studio/": {
		filePath: "/workspace/src/routes/studio.index.tsx",
		children: void 0,
		preloads: [
			"/assets/studio.index-2bfMNvcb.js",
			"/assets/app-shell-BVgSiuuC.js",
			"/assets/cast-store-C1KXldYv.js"
		]
	},
	"/read/$bookId/$kind/$chap": {
		filePath: "/workspace/src/routes/read.$bookId.$kind.$chap.tsx",
		children: void 0,
		preloads: [
			"/assets/read._bookId._kind._chap-tV1ihqm1.js",
			"/assets/app-shell-BVgSiuuC.js",
			"/assets/chevron-left-CMn1hByi.js",
			"/assets/compress-image-DnPnMof_.js",
			"/assets/article-text-DjT7UOpo.js",
			"/assets/ai-fns-BEg1-CQe.js",
			"/assets/cast-store-C1KXldYv.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
