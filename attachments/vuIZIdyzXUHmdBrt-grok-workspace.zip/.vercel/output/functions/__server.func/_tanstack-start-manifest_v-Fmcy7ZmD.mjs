//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Fmcy7ZmD.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/columns",
			"/intro",
			"/topics",
			"/view",
			"/book/$bookId",
			"/column/$slug",
			"/topic/$topicId",
			"/read/$bookId/$kind/$chap"
		],
		preloads: ["/assets/index-BYN2fFxu.js", "/assets/prefs-CrW5XWuI.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BYN2fFxu.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B68azpfo.js", "/assets/app-shell-bXF8n5Ln.js"]
	},
	"/columns": {
		filePath: "/workspace/src/routes/columns.tsx",
		children: void 0,
		preloads: ["/assets/columns-ncJ6yqit.js", "/assets/app-shell-bXF8n5Ln.js"]
	},
	"/intro": {
		filePath: "/workspace/src/routes/intro.tsx",
		children: void 0,
		preloads: ["/assets/intro-BrbB73sv.js", "/assets/app-shell-bXF8n5Ln.js"]
	},
	"/topics": {
		filePath: "/workspace/src/routes/topics.tsx",
		children: void 0,
		preloads: ["/assets/topics-BGWFpM-5.js", "/assets/app-shell-bXF8n5Ln.js"]
	},
	"/view": {
		filePath: "/workspace/src/routes/view.tsx",
		children: void 0,
		preloads: [
			"/assets/view-BYytCX8U.js",
			"/assets/app-shell-bXF8n5Ln.js",
			"/assets/chevron-left-C90nP_VM.js",
			"/assets/reader-view-mN1jL3lv.js"
		]
	},
	"/book/$bookId": {
		filePath: "/workspace/src/routes/book.$bookId.tsx",
		children: void 0,
		preloads: [
			"/assets/book._bookId-D3FN9--z.js",
			"/assets/app-shell-bXF8n5Ln.js",
			"/assets/chevron-left-C90nP_VM.js"
		]
	},
	"/column/$slug": {
		filePath: "/workspace/src/routes/column.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/column._slug-D2yvnIWb.js",
			"/assets/app-shell-bXF8n5Ln.js",
			"/assets/chevron-left-C90nP_VM.js"
		]
	},
	"/topic/$topicId": {
		filePath: "/workspace/src/routes/topic.$topicId.tsx",
		children: void 0,
		preloads: [
			"/assets/topic._topicId-DnmvVLHl.js",
			"/assets/app-shell-bXF8n5Ln.js",
			"/assets/chevron-left-C90nP_VM.js"
		]
	},
	"/read/$bookId/$kind/$chap": {
		filePath: "/workspace/src/routes/read.$bookId.$kind.$chap.tsx",
		children: void 0,
		preloads: [
			"/assets/read._bookId._kind._chap-BspjuoiH.js",
			"/assets/app-shell-bXF8n5Ln.js",
			"/assets/chevron-left-C90nP_VM.js",
			"/assets/reader-view-mN1jL3lv.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
