import { t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { f as createSsrRpc } from "./router-GwWX3rwL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-fns-CcdJ2-pE.js
var extractPeopleFn = createServerFn({ method: "POST" }).validator(object({
	bookId: string(),
	from: number().int().min(1).max(150),
	to: number().int().min(1).max(150)
})).handler(createSsrRpc("5b7ce5c602e640d1231901ed5f9b8b5cf61717457649875fa73d8d743282f9e8"));
var makePortraitFn = createServerFn({ method: "POST" }).validator(object({
	name: string().min(1).max(40),
	brief: string().max(800),
	look: string().max(600),
	styleId: string(),
	lockedImage: string().max(18e5).optional()
})).handler(createSsrRpc("f9b9c9b95c254d332b931ecca7a7704b9d8a2bddafe1e1966483cf9b2976558b"));
var makeSceneFn = createServerFn({ method: "POST" }).validator(object({
	bookName: string(),
	chapter: number().int(),
	passage: string().max(4e3),
	styleId: string(),
	people: array(object({
		name: string(),
		image: string().max(18e5)
	})).max(4)
})).handler(createSsrRpc("10cea72e0ea4c5a97438e9aa2a6b69104214469d65162744eddce01f9a072be5"));
var askStudyFn = createServerFn({ method: "POST" }).validator(object({
	question: string().min(1).max(600),
	title: string().max(120),
	source: string().max(12e3),
	history: array(object({
		role: _enum(["user", "assistant"]),
		content: string().max(2e3)
	})).max(8).optional()
})).handler(createSsrRpc("4e9d8d773ce1c75eee77a24bf65a6da0de5c2d8f72310f05602b7f87df0c2b91"));
var startClipFn = createServerFn({ method: "POST" }).validator(object({
	image: string().max(18e5),
	name: string().max(40)
})).handler(createSsrRpc("1fa244060d9e326902e4927fb7076b3a6812f5f24461d510fdb058b2f2192ea6"));
var pollClipFn = createServerFn({ method: "POST" }).validator(object({ requestId: string().min(4).max(80) })).handler(createSsrRpc("cc322a8052a92a6c92aea8a3aa3cc3faec780468a30c7c2981ac6521dcedee53"));
//#endregion
export { pollClipFn as a, makeSceneFn as i, extractPeopleFn as n, startClipFn as o, makePortraitFn as r, askStudyFn as t };
